#pragma once

#include "ComponentStorage.h"

using namespace Pro::Entity;

namespace Pro {
	namespace Engine {
		class Scene {

			ComponentStorage objects;

		public:
			Scene() {

			}
		};
	}
}