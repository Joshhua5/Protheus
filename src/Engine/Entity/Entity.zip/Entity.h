#pragma once

#include "Component.h"

namespace Pro {
	namespace Entity {
		// A entity is a collection of components
		// Used by the components to access other components


		class Entity {

		public: 
		};
	}
}