#pragma once
 
namespace Pro {
	namespace Entity {
		struct ComponentData {};
	}
}