/*************************************************************************
Protheus Source File.
Copyright (C), Protheus Studios, 2013-2014.
-------------------------------------------------------------------------

Description:
The entry point will load the lua config, if the config can't be found
DataGame will be assumed and will look for the game file, if neither
can be found then the program will exit.
-------------------------------------------------------------------------
History:
- 20:05:2014: Waring J.
*************************************************************************/
 
