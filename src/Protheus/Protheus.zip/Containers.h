/*************************************************************************
Protheus Source File.
Copyright (C), Protheus Studios, 2013-2014.
-------------------------------------------------------------------------

Description:

-------------------------------------------------------------------------
History:
- 09:06:2014 Waring J.

*************************************************************************/
#pragma once

#include "containers\CameraContainer.h"
#include "containers\EntityContainer.h"
#include "containers\SceneContainer.h"
#include "containers\WindowContainer.h"