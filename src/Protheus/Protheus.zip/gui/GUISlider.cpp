#include "GUISlider.h"

using namespace Pro;
using namespace GUI;

GUISlider::GUISlider(const std::string& name) : GUIEntity(name){}
GUISlider::GUISlider() : GUIEntity(){} 