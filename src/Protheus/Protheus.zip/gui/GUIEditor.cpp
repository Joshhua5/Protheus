#include "GUIEditor.h"

using namespace Pro;
using namespace GUI;

GUIEditor::GUIEditor()
{
} 