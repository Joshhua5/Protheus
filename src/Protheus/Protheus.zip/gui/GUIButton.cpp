#include "GUIButton.h"

using namespace Pro;
using namespace GUI;

GUIButton::GUIButton(const std::string& name) : GUIEntity(name){
}

GUIButton::GUIButton() : GUIEntity()
{
}
 