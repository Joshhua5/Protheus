#include "GUIMenuBar.h"

using namespace Pro;
using namespace GUI;

GUIMenuBar::GUIMenuBar(const std::string& name) : GUIEntity(name){}
GUIMenuBar::GUIMenuBar() : GUIEntity() {}
 