#include "GUILabel.h"

using namespace Pro;
using namespace GUI;

GUILabel::GUILabel(const std::string& name) : GUIEntity(name){}
GUILabel::GUILabel() : GUIEntity() {}
 