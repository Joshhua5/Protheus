#include "GUICollapsibleMenu.h"

using namespace Pro;
using namespace GUI;

GUICollapsibleMenu::GUICollapsibleMenu(const std::string& name) : GUIContainer(name){}

GUICollapsibleMenu::GUICollapsibleMenu() : GUIContainer(){} 