#include "GUIText.h"

using namespace Pro;
using namespace GUI;

GUIText::GUIText(const std::string& name) : GUIEntity(name){}
GUIText::GUIText() : GUIEntity() {} 