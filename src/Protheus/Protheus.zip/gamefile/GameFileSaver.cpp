#include "GameFileSaver.h"


GameFileSaver::GameFileSaver()
{
}


GameFileSaver::~GameFileSaver()
{
}
