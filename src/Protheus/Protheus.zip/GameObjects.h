/*************************************************************************
Protheus Source File.
Copyright (C), Protheus Studios, 2013-2014.
-------------------------------------------------------------------------

Description:

-------------------------------------------------------------------------
History:
- 17:05:2014 Waring J.

*************************************************************************/
#pragma once

#include "gameobject\StaticEntity.h"
#include "gameobject\DynamicEntity.h"
#include "gameobject\DataEntity.h"